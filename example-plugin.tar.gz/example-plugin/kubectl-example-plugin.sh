
#!/bin/bash

echo "Hello from example-plugin!"
